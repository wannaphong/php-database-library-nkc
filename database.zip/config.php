<?php
$name_web="ระบบยืม-คืนหนังสือห้องสมุด";
$fine=5;
$dateborrow=' +5 day';
?>