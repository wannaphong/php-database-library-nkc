<header>
    <img src="9.png" class="responsive">
</header>